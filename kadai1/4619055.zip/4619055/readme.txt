4619055 辰川力駆が作成した実験1のプログラムである。

cluster.c:クラスタ係数を求めるプログラムである。
コンパイル: gcc -o cluster clutster.c 
実行: ./cluster


length.c:平均頂点間距離を求めるプログラムである。
コンパイル: gcc -o length length.c
実行: ./length


randomize.cpp:ランダマイズするプログラムである。
コンパイル: g++ -o randomize randomize.cpp

実行: ./randomize seed値

実際に実験で使用したseed値: ./randomize 3